#!/bin/bash

# Create data aggregation directory
workdir="/var/tmp/hcl_data"
if [ ! -d $workdir ]; then
  /bin/mkdir $workdir
fi

# Run Support Script Capture Task on all infrastructure nodes
/opt/puppetlabs/bin/puppet task run --query 'resources[certname] { (type = "Class" and title = "Puppet_enterprise::Profile::Master") or (type = "Class" and title = "Puppet_enterprise::Profile::Puppetdb") or (type = "Class" and title = "Puppet_enterprise::Profile::Console") }' healthcheck_lite::supportcapture
