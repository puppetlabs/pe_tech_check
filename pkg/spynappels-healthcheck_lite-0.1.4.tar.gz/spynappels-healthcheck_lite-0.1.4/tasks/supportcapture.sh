#!/bin/sh

/opt/puppetlabs/bin/puppet enterprise support --log-age 0
